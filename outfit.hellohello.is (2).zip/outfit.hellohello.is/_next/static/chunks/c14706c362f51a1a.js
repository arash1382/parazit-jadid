(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 88133, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "InvariantError", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    class n extends Error {
        constructor(e, t) {
            super(`Invariant: ${e.endsWith(".")?e:e+"."} This is a bug in Next.js.`, t), this.name = "InvariantError"
        }
    }
}, 32974, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        BailoutToCSRError: function() {
            return i
        },
        isBailoutToCSRError: function() {
            return u
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let o = "BAILOUT_TO_CLIENT_SIDE_RENDERING";
    class i extends Error {
        constructor(e) {
            super(`Bail out to client-side rendering: ${e}`), this.reason = e, this.digest = o
        }
    }

    function u(e) {
        return "object" == typeof e && null !== e && "digest" in e && e.digest === o
    }
}, 39057, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        HTTPAccessErrorStatus: function() {
            return o
        },
        HTTP_ERROR_FALLBACK_ERROR_CODE: function() {
            return u
        },
        getAccessFallbackErrorTypeByStatus: function() {
            return d
        },
        getAccessFallbackHTTPStatus: function() {
            return c
        },
        isHTTPAccessFallbackError: function() {
            return s
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let o = {
            NOT_FOUND: 404,
            FORBIDDEN: 403,
            UNAUTHORIZED: 401
        },
        i = new Set(Object.values(o)),
        u = "NEXT_HTTP_ERROR_FALLBACK";

    function s(e) {
        if ("object" != typeof e || null === e || !("digest" in e) || "string" != typeof e.digest) return !1;
        let [t, r] = e.digest.split(";");
        return t === u && i.has(Number(r))
    }

    function c(e) {
        return Number(e.digest.split(";")[1])
    }

    function d(e) {
        switch (e) {
            case 401:
                return "unauthorized";
            case 403:
                return "forbidden";
            case 404:
                return "not-found";
            default:
                return
        }
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 97261, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "isNextRouterError", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    let n = e.r(39057),
        a = e.r(93945);

    function o(e) {
        return (0, a.isRedirectError)(e) || (0, n.isHTTPAccessFallbackError)(e)
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 85127, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "ReadonlyURLSearchParams", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    class n extends Error {
        constructor() {
            super("Method unavailable on `ReadonlyURLSearchParams`. Read more: https://nextjs.org/docs/app/api-reference/functions/use-search-params#updating-searchparams")
        }
    }
    class a extends URLSearchParams {
        append() {
            throw new n
        }
        delete() {
            throw new n
        }
        set() {
            throw new n
        }
        sort() {
            throw new n
        }
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 62631, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        NavigationPromisesContext: function() {
            return d
        },
        PathParamsContext: function() {
            return c
        },
        PathnameContext: function() {
            return s
        },
        ReadonlyURLSearchParams: function() {
            return i.ReadonlyURLSearchParams
        },
        SearchParamsContext: function() {
            return u
        },
        createDevToolsInstrumentedPromise: function() {
            return l
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let o = e.r(59888),
        i = e.r(85127),
        u = (0, o.createContext)(null),
        s = (0, o.createContext)(null),
        c = (0, o.createContext)(null),
        d = (0, o.createContext)(null);

    function l(e, t) {
        let r = Promise.resolve(t);
        return r.status = "fulfilled", r.value = t, r.displayName = `${e} (SSR)`, r
    }
}, 6101, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "workUnitAsyncStorageInstance", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = (0, e.r(44823).createAsyncLocalStorage)()
}, 30900, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        getCacheSignal: function() {
            return y
        },
        getDraftModeProviderForCacheScope: function() {
            return m
        },
        getHmrRefreshHash: function() {
            return f
        },
        getPrerenderResumeDataCache: function() {
            return d
        },
        getRenderResumeDataCache: function() {
            return l
        },
        getRuntimeStagePromise: function() {
            return b
        },
        getServerComponentsHmrCache: function() {
            return h
        },
        isHmrRefresh: function() {
            return p
        },
        throwForMissingRequestStore: function() {
            return s
        },
        throwInvariantForMissingStore: function() {
            return c
        },
        workUnitAsyncStorage: function() {
            return o.workUnitAsyncStorageInstance
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let o = e.r(6101),
        i = e.r(36523),
        u = e.r(88133);

    function s(e) {
        throw Object.defineProperty(Error(`\`${e}\` was called outside a request scope. Read more: https://nextjs.org/docs/messages/next-dynamic-api-wrong-context`), "__NEXT_ERROR_CODE", {
            value: "E251",
            enumerable: !1,
            configurable: !0
        })
    }

    function c() {
        throw Object.defineProperty(new u.InvariantError("Expected workUnitAsyncStorage to have a store."), "__NEXT_ERROR_CODE", {
            value: "E696",
            enumerable: !1,
            configurable: !0
        })
    }

    function d(e) {
        switch (e.type) {
            case "prerender":
            case "prerender-runtime":
            case "prerender-ppr":
            case "prerender-client":
                return e.prerenderResumeDataCache;
            case "request":
                if (e.prerenderResumeDataCache) return e.prerenderResumeDataCache;
            case "prerender-legacy":
            case "cache":
            case "private-cache":
            case "unstable-cache":
                return null;
            default:
                return e
        }
    }

    function l(e) {
        switch (e.type) {
            case "request":
            case "prerender":
            case "prerender-runtime":
            case "prerender-client":
                if (e.renderResumeDataCache) return e.renderResumeDataCache;
            case "prerender-ppr":
                return e.prerenderResumeDataCache ? ? null;
            case "cache":
            case "private-cache":
            case "unstable-cache":
            case "prerender-legacy":
                return null;
            default:
                return e
        }
    }

    function f(e, t) {
        if (e.dev) switch (t.type) {
            case "cache":
            case "private-cache":
            case "prerender":
            case "prerender-runtime":
                return t.hmrRefreshHash;
            case "request":
                var r;
                return null == (r = t.cookies.get(i.NEXT_HMR_REFRESH_HASH_COOKIE)) ? void 0 : r.value
        }
    }

    function p(e, t) {
        if (e.dev) switch (t.type) {
            case "cache":
            case "private-cache":
            case "request":
                return t.isHmrRefresh ? ? !1
        }
        return !1
    }

    function h(e, t) {
        if (e.dev) switch (t.type) {
            case "cache":
            case "private-cache":
            case "request":
                return t.serverComponentsHmrCache
        }
    }

    function m(e, t) {
        if (e.isDraftMode) switch (t.type) {
            case "cache":
            case "private-cache":
            case "unstable-cache":
            case "prerender-runtime":
            case "request":
                return t.draftMode
        }
    }

    function y(e) {
        switch (e.type) {
            case "prerender":
            case "prerender-client":
            case "prerender-runtime":
                return e.cacheSignal;
            case "request":
                if (e.cacheSignal) return e.cacheSignal;
            case "prerender-ppr":
            case "prerender-legacy":
            case "cache":
            case "private-cache":
            case "unstable-cache":
                return null;
            default:
                return e
        }
    }

    function b(e) {
        switch (e.type) {
            case "prerender-runtime":
            case "private-cache":
                return e.runtimeStagePromise;
            case "prerender":
            case "prerender-client":
            case "prerender-ppr":
            case "prerender-legacy":
            case "request":
            case "cache":
            case "unstable-cache":
                return null;
            default:
                return e
        }
    }
}, 93808, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        ServerInsertedHTMLContext: function() {
            return i
        },
        useServerInsertedHTML: function() {
            return u
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let o = e.r(44066)._(e.r(59888)),
        i = o.default.createContext(null);

    function u(e) {
        let t = (0, o.useContext)(i);
        t && t(e)
    }
}, 13269, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "notFound", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    let n = e.r(39057),
        a = `${n.HTTP_ERROR_FALLBACK_ERROR_CODE};404`;

    function o() {
        let e = Object.defineProperty(Error(a), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: !1,
            configurable: !0
        });
        throw e.digest = a, e
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 77798, (e, t, r) => {
    "use strict";

    function n() {
        throw Object.defineProperty(Error("`forbidden()` is experimental and only allowed to be enabled when `experimental.authInterrupts` is enabled."), "__NEXT_ERROR_CODE", {
            value: "E488",
            enumerable: !1,
            configurable: !0
        })
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "forbidden", {
        enumerable: !0,
        get: function() {
            return n
        }
    }), e.r(39057).HTTP_ERROR_FALLBACK_ERROR_CODE, ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 49075, (e, t, r) => {
    "use strict";

    function n() {
        throw Object.defineProperty(Error("`unauthorized()` is experimental and only allowed to be used when `experimental.authInterrupts` is enabled."), "__NEXT_ERROR_CODE", {
            value: "E411",
            enumerable: !1,
            configurable: !0
        })
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "unauthorized", {
        enumerable: !0,
        get: function() {
            return n
        }
    }), e.r(39057).HTTP_ERROR_FALLBACK_ERROR_CODE, ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 19034, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "unstable_rethrow", {
        enumerable: !0,
        get: function() {
            return function e(t) {
                if ((0, a.isNextRouterError)(t) || (0, n.isBailoutToCSRError)(t)) throw t;
                t instanceof Error && "cause" in t && e(t.cause)
            }
        }
    });
    let n = e.r(32974),
        a = e.r(97261);
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 60555, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        isHangingPromiseRejectionError: function() {
            return o
        },
        makeDevtoolsIOAwarePromise: function() {
            return l
        },
        makeHangingPromise: function() {
            return c
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });

    function o(e) {
        return "object" == typeof e && null !== e && "digest" in e && e.digest === i
    }
    let i = "HANGING_PROMISE_REJECTION";
    class u extends Error {
        constructor(e, t) {
            super(`During prerendering, ${t} rejects when the prerender is complete. Typically these errors are handled by React but if you move ${t} to a different context by using \`setTimeout\`, \`after\`, or similar functions you may observe this error and you should handle it in that context. This occurred at route "${e}".`), this.route = e, this.expression = t, this.digest = i
        }
    }
    let s = new WeakMap;

    function c(e, t, r) {
        if (e.aborted) return Promise.reject(new u(t, r)); {
            let n = new Promise((n, a) => {
                let o = a.bind(null, new u(t, r)),
                    i = s.get(e);
                if (i) i.push(o);
                else {
                    let t = [o];
                    s.set(e, t), e.addEventListener("abort", () => {
                        for (let e = 0; e < t.length; e++) t[e]()
                    }, {
                        once: !0
                    })
                }
            });
            return n.catch(d), n
        }
    }

    function d() {}

    function l(e, t, r) {
        return t.stagedRendering ? t.stagedRendering.delayUntilStage(r, void 0, e) : new Promise(t => {
            setTimeout(() => {
                t(e)
            }, 0)
        })
    }
}, 68838, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "isPostpone", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = Symbol.for("react.postpone");

    function a(e) {
        return "object" == typeof e && null !== e && e.$$typeof === n
    }
}, 5350, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        DynamicServerError: function() {
            return i
        },
        isDynamicServerError: function() {
            return u
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let o = "DYNAMIC_SERVER_USAGE";
    class i extends Error {
        constructor(e) {
            super(`Dynamic server usage: ${e}`), this.description = e, this.digest = o
        }
    }

    function u(e) {
        return "object" == typeof e && null !== e && "digest" in e && "string" == typeof e.digest && e.digest === o
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 79e3, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        StaticGenBailoutError: function() {
            return i
        },
        isStaticGenBailoutError: function() {
            return u
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let o = "NEXT_STATIC_GEN_BAILOUT";
    class i extends Error {
        constructor(...e) {
            super(...e), this.code = o
        }
    }

    function u(e) {
        return "object" == typeof e && null !== e && "code" in e && e.code === o
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 2717, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        METADATA_BOUNDARY_NAME: function() {
            return o
        },
        OUTLET_BOUNDARY_NAME: function() {
            return u
        },
        ROOT_LAYOUT_BOUNDARY_NAME: function() {
            return s
        },
        VIEWPORT_BOUNDARY_NAME: function() {
            return i
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let o = "__next_metadata_boundary__",
        i = "__next_viewport_boundary__",
        u = "__next_outlet_boundary__",
        s = "__next_root_layout_boundary__"
}, 69842, (e, t, r) => {
    "use strict";
    var n = e.i(7240);
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var a = {
        atLeastOneTask: function() {
            return s
        },
        scheduleImmediate: function() {
            return u
        },
        scheduleOnNextTick: function() {
            return i
        },
        waitAtLeastOneReactRenderTask: function() {
            return c
        }
    };
    for (var o in a) Object.defineProperty(r, o, {
        enumerable: !0,
        get: a[o]
    });
    let i = e => {
            Promise.resolve().then(() => {
                n.default.nextTick(e)
            })
        },
        u = e => {
            setImmediate(e)
        };

    function s() {
        return new Promise(e => u(e))
    }

    function c() {
        return new Promise(e => setImmediate(e))
    }
}, 61673, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n, a, o = {
        Postpone: function() {
            return j
        },
        PreludeState: function() {
            return Z
        },
        abortAndThrowOnSynchronousRequestDataAccess: function() {
            return S
        },
        abortOnSynchronousPlatformIOAccess: function() {
            return P
        },
        accessedDynamicData: function() {
            return N
        },
        annotateDynamicAccess: function() {
            return B
        },
        consumeDynamicAccess: function() {
            return I
        },
        createDynamicTrackingState: function() {
            return g
        },
        createDynamicValidationState: function() {
            return _
        },
        createHangingInputAbortSignal: function() {
            return $
        },
        createRenderInBrowserAbortSignal: function() {
            return L
        },
        delayUntilRuntimeStage: function() {
            return er
        },
        formatDynamicAPIAccesses: function() {
            return U
        },
        getFirstDynamicReason: function() {
            return E
        },
        getStaticShellDisallowedDynamicReasons: function() {
            return et
        },
        isDynamicPostpone: function() {
            return x
        },
        isPrerenderInterruptedError: function() {
            return k
        },
        logDisallowedDynamicError: function() {
            return Q
        },
        markCurrentScopeAsDynamic: function() {
            return R
        },
        postponeWithTracking: function() {
            return D
        },
        throwIfDisallowedDynamic: function() {
            return ee
        },
        throwToInterruptStaticGeneration: function() {
            return v
        },
        trackAllowedDynamicAccess: function() {
            return Y
        },
        trackDynamicDataInDynamicRender: function() {
            return O
        },
        trackDynamicHoleInRuntimeShell: function() {
            return V
        },
        trackDynamicHoleInStaticShell: function() {
            return K
        },
        useDynamicRouteParams: function() {
            return H
        },
        useDynamicSearchParams: function() {
            return X
        }
    };
    for (var i in o) Object.defineProperty(r, i, {
        enumerable: !0,
        get: o[i]
    });
    let u = (n = e.r(59888)) && n.__esModule ? n : {
            default: n
        },
        s = e.r(5350),
        c = e.r(79e3),
        d = e.r(30900),
        l = e.r(44140),
        f = e.r(60555),
        p = e.r(2717),
        h = e.r(69842),
        m = e.r(32974),
        y = e.r(88133),
        b = "function" == typeof u.default.unstable_postpone;

    function g(e) {
        return {
            isDebugDynamicAccesses: e,
            dynamicAccesses: [],
            syncDynamicErrorWithStack: null
        }
    }

    function _() {
        return {
            hasSuspenseAboveBody: !1,
            hasDynamicMetadata: !1,
            dynamicMetadata: null,
            hasDynamicViewport: !1,
            hasAllowedDynamic: !1,
            dynamicErrors: []
        }
    }

    function E(e) {
        var t;
        return null == (t = e.dynamicAccesses[0]) ? void 0 : t.expression
    }

    function R(e, t, r) {
        if (t) switch (t.type) {
            case "cache":
            case "unstable-cache":
            case "private-cache":
                return
        }
        if (!e.forceDynamic && !e.forceStatic) {
            if (e.dynamicShouldError) throw Object.defineProperty(new c.StaticGenBailoutError(`Route ${e.route} with \`dynamic = "error"\` couldn't be rendered statically because it used \`${r}\`. See more info here: https://nextjs.org/docs/app/building-your-application/rendering/static-and-dynamic#dynamic-rendering`), "__NEXT_ERROR_CODE", {
                value: "E553",
                enumerable: !1,
                configurable: !0
            });
            if (t) switch (t.type) {
                case "prerender-ppr":
                    return D(e.route, r, t.dynamicTracking);
                case "prerender-legacy":
                    t.revalidate = 0;
                    let n = Object.defineProperty(new s.DynamicServerError(`Route ${e.route} couldn't be rendered statically because it used ${r}. See more info here: https://nextjs.org/docs/messages/dynamic-server-error`), "__NEXT_ERROR_CODE", {
                        value: "E550",
                        enumerable: !1,
                        configurable: !0
                    });
                    throw e.dynamicUsageDescription = r, e.dynamicUsageStack = n.stack, n
            }
        }
    }

    function v(e, t, r) {
        let n = Object.defineProperty(new s.DynamicServerError(`Route ${t.route} couldn't be rendered statically because it used \`${e}\`. See more info here: https://nextjs.org/docs/messages/dynamic-server-error`), "__NEXT_ERROR_CODE", {
            value: "E558",
            enumerable: !1,
            configurable: !0
        });
        throw r.revalidate = 0, t.dynamicUsageDescription = e, t.dynamicUsageStack = n.stack, n
    }

    function O(e) {
        switch (e.type) {
            case "cache":
            case "unstable-cache":
            case "private-cache":
                return
        }
    }

    function w(e, t, r) {
        let n = C(`Route ${e} needs to bail out of prerendering at this point because it used ${t}.`);
        r.controller.abort(n);
        let a = r.dynamicTracking;
        a && a.dynamicAccesses.push({
            stack: a.isDebugDynamicAccesses ? Error().stack : void 0,
            expression: t
        })
    }

    function P(e, t, r, n) {
        let a = n.dynamicTracking;
        w(e, t, n), a && null === a.syncDynamicErrorWithStack && (a.syncDynamicErrorWithStack = r)
    }

    function S(e, t, r, n) {
        if (!1 === n.controller.signal.aborted) {
            w(e, t, n);
            let a = n.dynamicTracking;
            a && null === a.syncDynamicErrorWithStack && (a.syncDynamicErrorWithStack = r)
        }
        throw C(`Route ${e} needs to bail out of prerendering at this point because it used ${t}.`)
    }

    function j({
        reason: e,
        route: t
    }) {
        let r = d.workUnitAsyncStorage.getStore();
        D(t, e, r && "prerender-ppr" === r.type ? r.dynamicTracking : null)
    }

    function D(e, t, r) {
        (function() {
            if (!b) throw Object.defineProperty(Error("Invariant: React.unstable_postpone is not defined. This suggests the wrong version of React was loaded. This is a bug in Next.js"), "__NEXT_ERROR_CODE", {
                value: "E224",
                enumerable: !1,
                configurable: !0
            })
        })(), r && r.dynamicAccesses.push({
            stack: r.isDebugDynamicAccesses ? Error().stack : void 0,
            expression: t
        }), u.default.unstable_postpone(T(e, t))
    }

    function T(e, t) {
        return `Route ${e} needs to bail out of prerendering at this point because it used ${t}. React throws this special object to indicate where. It should not be caught by your own try/catch. Learn more: https://nextjs.org/docs/messages/ppr-caught-error`
    }

    function x(e) {
        return "object" == typeof e && null !== e && "string" == typeof e.message && A(e.message)
    }

    function A(e) {
        return e.includes("needs to bail out of prerendering at this point because it used") && e.includes("Learn more: https://nextjs.org/docs/messages/ppr-caught-error")
    }
    if (!1 === A(T("%%%", "^^^"))) throw Object.defineProperty(Error("Invariant: isDynamicPostpone misidentified a postpone reason. This is a bug in Next.js"), "__NEXT_ERROR_CODE", {
        value: "E296",
        enumerable: !1,
        configurable: !0
    });
    let M = "NEXT_PRERENDER_INTERRUPTED";

    function C(e) {
        let t = Object.defineProperty(Error(e), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: !1,
            configurable: !0
        });
        return t.digest = M, t
    }

    function k(e) {
        return "object" == typeof e && null !== e && e.digest === M && "name" in e && "message" in e && e instanceof Error
    }

    function N(e) {
        return e.length > 0
    }

    function I(e, t) {
        return e.dynamicAccesses.push(...t.dynamicAccesses), e.dynamicAccesses
    }

    function U(e) {
        return e.filter(e => "string" == typeof e.stack && e.stack.length > 0).map(({
            expression: e,
            stack: t
        }) => (t = t.split("\n").slice(4).filter(e => !(e.includes("node_modules/next/") || e.includes(" (<anonymous>)") || e.includes(" (node:"))).join("\n"), `Dynamic API Usage Debug - ${e}:
${t}`))
    }

    function L() {
        let e = new AbortController;
        return e.abort(Object.defineProperty(new m.BailoutToCSRError("Render in Browser"), "__NEXT_ERROR_CODE", {
            value: "E721",
            enumerable: !1,
            configurable: !0
        })), e.signal
    }

    function $(e) {
        switch (e.type) {
            case "prerender":
            case "prerender-runtime":
                let t = new AbortController;
                if (e.cacheSignal) e.cacheSignal.inputReady().then(() => {
                    t.abort()
                });
                else {
                    let r = (0, d.getRuntimeStagePromise)(e);
                    r ? r.then(() => (0, h.scheduleOnNextTick)(() => t.abort())) : (0, h.scheduleOnNextTick)(() => t.abort())
                }
                return t.signal;
            case "prerender-client":
            case "prerender-ppr":
            case "prerender-legacy":
            case "request":
            case "cache":
            case "private-cache":
            case "unstable-cache":
                return
        }
    }

    function B(e, t) {
        let r = t.dynamicTracking;
        r && r.dynamicAccesses.push({
            stack: r.isDebugDynamicAccesses ? Error().stack : void 0,
            expression: e
        })
    }

    function H(e) {
        let t = l.workAsyncStorage.getStore(),
            r = d.workUnitAsyncStorage.getStore();
        if (t && r) switch (r.type) {
            case "prerender-client":
            case "prerender":
                {
                    let n = r.fallbackRouteParams;n && n.size > 0 && u.default.use((0, f.makeHangingPromise)(r.renderSignal, t.route, e));
                    break
                }
            case "prerender-ppr":
                {
                    let n = r.fallbackRouteParams;
                    if (n && n.size > 0) return D(t.route, e, r.dynamicTracking);
                    break
                }
            case "prerender-runtime":
                throw Object.defineProperty(new y.InvariantError(`\`${e}\` was called during a runtime prerender. Next.js should be preventing ${e} from being included in server components statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                    value: "E771",
                    enumerable: !1,
                    configurable: !0
                });
            case "cache":
            case "private-cache":
                throw Object.defineProperty(new y.InvariantError(`\`${e}\` was called inside a cache scope. Next.js should be preventing ${e} from being included in server components statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                    value: "E745",
                    enumerable: !1,
                    configurable: !0
                })
        }
    }

    function X(e) {
        let t = l.workAsyncStorage.getStore(),
            r = d.workUnitAsyncStorage.getStore();
        if (t) switch (!r && (0, d.throwForMissingRequestStore)(e), r.type) {
            case "prerender-client":
                u.default.use((0, f.makeHangingPromise)(r.renderSignal, t.route, e));
                break;
            case "prerender-legacy":
            case "prerender-ppr":
                if (t.forceStatic) return;
                throw Object.defineProperty(new m.BailoutToCSRError(e), "__NEXT_ERROR_CODE", {
                    value: "E394",
                    enumerable: !1,
                    configurable: !0
                });
            case "prerender":
            case "prerender-runtime":
                throw Object.defineProperty(new y.InvariantError(`\`${e}\` was called from a Server Component. Next.js should be preventing ${e} from being included in server components statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                    value: "E795",
                    enumerable: !1,
                    configurable: !0
                });
            case "cache":
            case "unstable-cache":
            case "private-cache":
                throw Object.defineProperty(new y.InvariantError(`\`${e}\` was called inside a cache scope. Next.js should be preventing ${e} from being included in server components statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                    value: "E745",
                    enumerable: !1,
                    configurable: !0
                });
            case "request":
                return
        }
    }
    let F = /\n\s+at Suspense \(<anonymous>\)/,
        W = RegExp(`\\n\\s+at Suspense \\(<anonymous>\\)(?:(?!\\n\\s+at (?:body|div|main|section|article|aside|header|footer|nav|form|p|span|h1|h2|h3|h4|h5|h6) \\(<anonymous>\\))[\\s\\S])*?\\n\\s+at ${p.ROOT_LAYOUT_BOUNDARY_NAME} \\([^\\n]*\\)`),
        q = RegExp(`\\n\\s+at ${p.METADATA_BOUNDARY_NAME}[\\n\\s]`),
        G = RegExp(`\\n\\s+at ${p.VIEWPORT_BOUNDARY_NAME}[\\n\\s]`),
        z = RegExp(`\\n\\s+at ${p.OUTLET_BOUNDARY_NAME}[\\n\\s]`);

    function Y(e, t, r, n) {
        if (!z.test(t)) {
            if (q.test(t)) {
                r.hasDynamicMetadata = !0;
                return
            }
            if (G.test(t)) {
                r.hasDynamicViewport = !0;
                return
            }
            if (W.test(t)) {
                r.hasAllowedDynamic = !0, r.hasSuspenseAboveBody = !0;
                return
            } else if (F.test(t)) {
                r.hasAllowedDynamic = !0;
                return
            } else {
                if (n.syncDynamicErrorWithStack) return void r.dynamicErrors.push(n.syncDynamicErrorWithStack);
                let a = J(`Route "${e.route}": Uncached data was accessed outside of <Suspense>. This delays the entire page from rendering, resulting in a slow user experience. Learn more: https://nextjs.org/docs/messages/blocking-route`, t);
                return void r.dynamicErrors.push(a)
            }
        }
    }

    function V(e, t, r, n) {
        if (!z.test(t)) {
            if (q.test(t)) {
                r.dynamicMetadata = J(`Route "${e.route}": Uncached data or \`connection()\` was accessed inside \`generateMetadata\`. Except for this instance, the page would have been entirely prerenderable which may have been the intended behavior. See more info here: https://nextjs.org/docs/messages/next-prerender-dynamic-metadata`, t);
                return
            }
            if (G.test(t)) {
                let n = J(`Route "${e.route}": Uncached data or \`connection()\` was accessed inside \`generateViewport\`. This delays the entire page from rendering, resulting in a slow user experience. Learn more: https://nextjs.org/docs/messages/next-prerender-dynamic-viewport`, t);
                r.dynamicErrors.push(n);
                return
            }
            if (W.test(t)) {
                r.hasAllowedDynamic = !0, r.hasSuspenseAboveBody = !0;
                return
            } else if (F.test(t)) {
                r.hasAllowedDynamic = !0;
                return
            } else {
                if (n.syncDynamicErrorWithStack) return void r.dynamicErrors.push(n.syncDynamicErrorWithStack);
                let a = J(`Route "${e.route}": Uncached data or \`connection()\` was accessed outside of \`<Suspense>\`. This delays the entire page from rendering, resulting in a slow user experience. Learn more: https://nextjs.org/docs/messages/blocking-route`, t);
                return void r.dynamicErrors.push(a)
            }
        }
    }

    function K(e, t, r, n) {
        if (!z.test(t)) {
            if (q.test(t)) {
                r.dynamicMetadata = J(`Route "${e.route}": Runtime data such as \`cookies()\`, \`headers()\`, \`params\`, or \`searchParams\` was accessed inside \`generateMetadata\` or you have file-based metadata such as icons that depend on dynamic params segments. Except for this instance, the page would have been entirely prerenderable which may have been the intended behavior. See more info here: https://nextjs.org/docs/messages/next-prerender-dynamic-metadata`, t);
                return
            }
            if (G.test(t)) {
                let n = J(`Route "${e.route}": Runtime data such as \`cookies()\`, \`headers()\`, \`params\`, or \`searchParams\` was accessed inside \`generateViewport\`. This delays the entire page from rendering, resulting in a slow user experience. Learn more: https://nextjs.org/docs/messages/next-prerender-dynamic-viewport`, t);
                r.dynamicErrors.push(n);
                return
            }
            if (W.test(t)) {
                r.hasAllowedDynamic = !0, r.hasSuspenseAboveBody = !0;
                return
            } else if (F.test(t)) {
                r.hasAllowedDynamic = !0;
                return
            } else {
                if (n.syncDynamicErrorWithStack) return void r.dynamicErrors.push(n.syncDynamicErrorWithStack);
                let a = J(`Route "${e.route}": Runtime data such as \`cookies()\`, \`headers()\`, \`params\`, or \`searchParams\` was accessed outside of \`<Suspense>\`. This delays the entire page from rendering, resulting in a slow user experience. Learn more: https://nextjs.org/docs/messages/blocking-route`, t);
                return void r.dynamicErrors.push(a)
            }
        }
    }

    function J(e, t) {
        let r = Object.defineProperty(Error(e), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: !1,
            configurable: !0
        });
        return r.stack = r.name + ": " + e + t, r
    }
    var Z = ((a = {})[a.Full = 0] = "Full", a[a.Empty = 1] = "Empty", a[a.Errored = 2] = "Errored", a);

    function Q(e, t) {
        console.error(t), e.dev || (e.hasReadableErrorStacks ? console.error(`To get a more detailed stack trace and pinpoint the issue, start the app in development mode by running \`next dev\`, then open "${e.route}" in your browser to investigate the error.`) : console.error(`To get a more detailed stack trace and pinpoint the issue, try one of the following:
  - Start the app in development mode by running \`next dev\`, then open "${e.route}" in your browser to investigate the error.
  - Rerun the production build with \`next build --debug-prerender\` to generate better stack traces.`))
    }

    function ee(e, t, r, n) {
        if (n.syncDynamicErrorWithStack) throw Q(e, n.syncDynamicErrorWithStack), new c.StaticGenBailoutError;
        if (0 !== t) {
            if (r.hasSuspenseAboveBody) return;
            let n = r.dynamicErrors;
            if (n.length > 0) {
                for (let t = 0; t < n.length; t++) Q(e, n[t]);
                throw new c.StaticGenBailoutError
            }
            if (r.hasDynamicViewport) throw console.error(`Route "${e.route}" has a \`generateViewport\` that depends on Request data (\`cookies()\`, etc...) or uncached external data (\`fetch(...)\`, etc...) without explicitly allowing fully dynamic rendering. See more info here: https://nextjs.org/docs/messages/next-prerender-dynamic-viewport`), new c.StaticGenBailoutError;
            if (1 === t) throw console.error(`Route "${e.route}" did not produce a static shell and Next.js was unable to determine a reason. This is a bug in Next.js.`), new c.StaticGenBailoutError
        } else if (!1 === r.hasAllowedDynamic && r.hasDynamicMetadata) throw console.error(`Route "${e.route}" has a \`generateMetadata\` that depends on Request data (\`cookies()\`, etc...) or uncached external data (\`fetch(...)\`, etc...) when the rest of the route does not. See more info here: https://nextjs.org/docs/messages/next-prerender-dynamic-metadata`), new c.StaticGenBailoutError
    }

    function et(e, t, r) {
        if (r.hasSuspenseAboveBody) return [];
        if (0 !== t) {
            let n = r.dynamicErrors;
            if (n.length > 0) return n;
            if (1 === t) return [Object.defineProperty(new y.InvariantError(`Route "${e.route}" did not produce a static shell and Next.js was unable to determine a reason.`), "__NEXT_ERROR_CODE", {
                value: "E936",
                enumerable: !1,
                configurable: !0
            })]
        } else if (!1 === r.hasAllowedDynamic && 0 === r.dynamicErrors.length && r.dynamicMetadata) return [r.dynamicMetadata];
        return []
    }

    function er(e, t) {
        return e.runtimeStagePromise ? e.runtimeStagePromise.then(() => t) : t
    }
}, 86882, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "unstable_rethrow", {
        enumerable: !0,
        get: function() {
            return function e(t) {
                if ((0, i.isNextRouterError)(t) || (0, o.isBailoutToCSRError)(t) || (0, s.isDynamicServerError)(t) || (0, u.isDynamicPostpone)(t) || (0, a.isPostpone)(t) || (0, n.isHangingPromiseRejectionError)(t) || (0, u.isPrerenderInterruptedError)(t)) throw t;
                t instanceof Error && "cause" in t && e(t.cause)
            }
        }
    });
    let n = e.r(60555),
        a = e.r(68838),
        o = e.r(32974),
        i = e.r(97261),
        u = e.r(61673),
        s = e.r(5350);
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 17401, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "unstable_rethrow", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = "undefined" == typeof window ? e.r(86882).unstable_rethrow : e.r(19034).unstable_rethrow;
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 31679, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        ReadonlyURLSearchParams: function() {
            return o.ReadonlyURLSearchParams
        },
        RedirectType: function() {
            return u.RedirectType
        },
        forbidden: function() {
            return c.forbidden
        },
        notFound: function() {
            return s.notFound
        },
        permanentRedirect: function() {
            return i.permanentRedirect
        },
        redirect: function() {
            return i.redirect
        },
        unauthorized: function() {
            return d.unauthorized
        },
        unstable_isUnrecognizedActionError: function() {
            return f
        },
        unstable_rethrow: function() {
            return l.unstable_rethrow
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let o = e.r(85127),
        i = e.r(44462),
        u = e.r(93945),
        s = e.r(13269),
        c = e.r(77798),
        d = e.r(49075),
        l = e.r(17401);

    function f() {
        throw Object.defineProperty(Error("`unstable_isUnrecognizedActionError` can only be used on the client."), "__NEXT_ERROR_CODE", {
            value: "E776",
            enumerable: !1,
            configurable: !0
        })
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 92400, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        ReadonlyURLSearchParams: function() {
            return u.ReadonlyURLSearchParams
        },
        RedirectType: function() {
            return l.RedirectType
        },
        ServerInsertedHTMLContext: function() {
            return c.ServerInsertedHTMLContext
        },
        forbidden: function() {
            return l.forbidden
        },
        notFound: function() {
            return l.notFound
        },
        permanentRedirect: function() {
            return l.permanentRedirect
        },
        redirect: function() {
            return l.redirect
        },
        unauthorized: function() {
            return l.unauthorized
        },
        unstable_isUnrecognizedActionError: function() {
            return d.unstable_isUnrecognizedActionError
        },
        unstable_rethrow: function() {
            return l.unstable_rethrow
        },
        useParams: function() {
            return b
        },
        usePathname: function() {
            return m
        },
        useRouter: function() {
            return y
        },
        useSearchParams: function() {
            return h
        },
        useSelectedLayoutSegment: function() {
            return _
        },
        useSelectedLayoutSegments: function() {
            return g
        },
        useServerInsertedHTML: function() {
            return c.useServerInsertedHTML
        }
    };
    for (var a in n) Object.defineProperty(r, a, {
        enumerable: !0,
        get: n[a]
    });
    let o = e.r(44066)._(e.r(59888)),
        i = e.r(79638),
        u = e.r(62631),
        s = e.r(54086),
        c = e.r(93808),
        d = e.r(66688),
        l = e.r(31679),
        f = "undefined" == typeof window ? e.r(61673).useDynamicRouteParams : void 0,
        p = "undefined" == typeof window ? e.r(61673).useDynamicSearchParams : void 0;

    function h() {
        p ? .("useSearchParams()");
        let e = (0, o.useContext)(u.SearchParamsContext);
        return (0, o.useMemo)(() => e ? new u.ReadonlyURLSearchParams(e) : null, [e])
    }

    function m() {
        return f ? .("usePathname()"), (0, o.useContext)(u.PathnameContext)
    }

    function y() {
        let e = (0, o.useContext)(i.AppRouterContext);
        if (null === e) throw Object.defineProperty(Error("invariant expected app router to be mounted"), "__NEXT_ERROR_CODE", {
            value: "E238",
            enumerable: !1,
            configurable: !0
        });
        return e
    }

    function b() {
        return f ? .("useParams()"), (0, o.useContext)(u.PathParamsContext)
    }

    function g(e = "children") {
        f ? .("useSelectedLayoutSegments()");
        let t = (0, o.useContext)(i.LayoutRouterContext);
        return t ? (0, s.getSelectedLayoutSegmentPath)(t.parentTree, e) : null
    }

    function _(e = "children") {
        f ? .("useSelectedLayoutSegment()"), (0, o.useContext)(u.NavigationPromisesContext);
        let t = g(e);
        return (0, s.computeSelectedLayoutSegment)(t, e)
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}]);