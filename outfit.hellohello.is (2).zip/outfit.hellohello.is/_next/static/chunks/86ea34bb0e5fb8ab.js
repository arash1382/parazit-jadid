(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 3844, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "useUntrackedPathname", {
        enumerable: !0,
        get: function() {
            return u
        }
    });
    let n = e.r(59888),
        o = e.r(62631);

    function u() {
        return ! function() {
            if ("undefined" == typeof window) {
                let {
                    workUnitAsyncStorage: t
                } = e.r(30900), r = t.getStore();
                if (!r) return !1;
                switch (r.type) {
                    case "prerender":
                    case "prerender-client":
                    case "prerender-ppr":
                        let n = r.fallbackRouteParams;
                        return !!n && n.size > 0
                }
            }
            return !1
        }() ? (0, n.useContext)(o.PathnameContext) : null
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 99433, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        handleHardNavError: function() {
            return i
        },
        useNavFailureHandler: function() {
            return a
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    e.r(59888);
    let u = e.r(58168);

    function i(e) {
        return !!e && "undefined" != typeof window && !!window.next.__pendingUrl && (0, u.createHrefFromUrl)(new URL(window.location.href)) !== (0, u.createHrefFromUrl)(window.next.__pendingUrl) && (console.error("Error occurred during navigation, falling back to hard navigation", e), window.location.href = window.next.__pendingUrl.toString(), !0)
    }

    function a() {}("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 24202, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        ErrorBoundary: function() {
            return y
        },
        ErrorBoundaryHandler: function() {
            return p
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let u = e.r(81258),
        i = e.r(89822),
        a = u._(e.r(59888)),
        l = e.r(3844),
        s = e.r(97261);
    e.r(99433);
    let c = e.r(70223),
        f = e.r(79008),
        d = "undefined" != typeof window && (0, f.isBot)(window.navigator.userAgent);
    class p extends a.default.Component {
        constructor(e) {
            super(e), this.reset = () => {
                this.setState({
                    error: null
                })
            }, this.state = {
                error: null,
                previousPathname: this.props.pathname
            }
        }
        static getDerivedStateFromError(e) {
            if ((0, s.isNextRouterError)(e)) throw e;
            return {
                error: e
            }
        }
        static getDerivedStateFromProps(e, t) {
            let {
                error: r
            } = t;
            return e.pathname !== t.previousPathname && t.error ? {
                error: null,
                previousPathname: e.pathname
            } : {
                error: t.error,
                previousPathname: e.pathname
            }
        }
        render() {
            return this.state.error && !d ? (0, i.jsxs)(i.Fragment, {
                children: [(0, i.jsx)(c.HandleISRError, {
                    error: this.state.error
                }), this.props.errorStyles, this.props.errorScripts, (0, i.jsx)(this.props.errorComponent, {
                    error: this.state.error,
                    reset: this.reset
                })]
            }) : this.props.children
        }
    }

    function y({
        errorComponent: e,
        errorStyles: t,
        errorScripts: r,
        children: n
    }) {
        let o = (0, l.useUntrackedPathname)();
        return e ? (0, i.jsx)(p, {
            pathname: o,
            errorComponent: e,
            errorStyles: t,
            errorScripts: r,
            children: n
        }) : (0, i.jsx)(i.Fragment, {
            children: n
        })
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 75739, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        RedirectBoundary: function() {
            return p
        },
        RedirectErrorBoundary: function() {
            return d
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let u = e.r(44066),
        i = e.r(89822),
        a = u._(e.r(59888)),
        l = e.r(92400),
        s = e.r(44462),
        c = e.r(93945);

    function f({
        redirect: e,
        reset: t,
        redirectType: r
    }) {
        let n = (0, l.useRouter)();
        return (0, a.useEffect)(() => {
            a.default.startTransition(() => {
                r === c.RedirectType.push ? n.push(e, {}) : n.replace(e, {}), t()
            })
        }, [e, r, t, n]), null
    }
    class d extends a.default.Component {
        constructor(e) {
            super(e), this.state = {
                redirect: null,
                redirectType: null
            }
        }
        static getDerivedStateFromError(e) {
            if ((0, c.isRedirectError)(e)) {
                let t = (0, s.getURLFromRedirectError)(e),
                    r = (0, s.getRedirectTypeFromError)(e);
                return "handled" in e ? {
                    redirect: null,
                    redirectType: null
                } : {
                    redirect: t,
                    redirectType: r
                }
            }
            throw e
        }
        render() {
            let {
                redirect: e,
                redirectType: t
            } = this.state;
            return null !== e && null !== t ? (0, i.jsx)(f, {
                redirect: e,
                redirectType: t,
                reset: () => this.setState({
                    redirect: null
                })
            }) : this.props.children
        }
    }

    function p({
        children: e
    }) {
        let t = (0, l.useRouter)();
        return (0, i.jsx)(d, {
            router: t,
            children: e
        })
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 89788, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "unresolvedThenable", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = {
        then: () => {}
    };
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 82669, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        MetadataBoundary: function() {
            return a
        },
        OutletBoundary: function() {
            return s
        },
        RootLayoutBoundary: function() {
            return c
        },
        ViewportBoundary: function() {
            return l
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let u = e.r(2717),
        i = {
            [u.METADATA_BOUNDARY_NAME]: function({
                children: e
            }) {
                return e
            },
            [u.VIEWPORT_BOUNDARY_NAME]: function({
                children: e
            }) {
                return e
            },
            [u.OUTLET_BOUNDARY_NAME]: function({
                children: e
            }) {
                return e
            },
            [u.ROOT_LAYOUT_BOUNDARY_NAME]: function({
                children: e
            }) {
                return e
            }
        },
        a = i[u.METADATA_BOUNDARY_NAME.slice(0)],
        l = i[u.VIEWPORT_BOUNDARY_NAME.slice(0)],
        s = i[u.OUTLET_BOUNDARY_NAME.slice(0)],
        c = i[u.ROOT_LAYOUT_BOUNDARY_NAME.slice(0)]
}, 99487, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "workAsyncStorageInstance", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = (0, e.r(44823).createAsyncLocalStorage)()
}, 44140, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "workAsyncStorage", {
        enumerable: !0,
        get: function() {
            return n.workAsyncStorageInstance
        }
    });
    let n = e.r(99487)
}, 44823, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var n = {
        bindSnapshot: function() {
            return s
        },
        createAsyncLocalStorage: function() {
            return l
        },
        createSnapshot: function() {
            return c
        }
    };
    for (var o in n) Object.defineProperty(r, o, {
        enumerable: !0,
        get: n[o]
    });
    let u = Object.defineProperty(Error("Invariant: AsyncLocalStorage accessed in runtime where it is not available"), "__NEXT_ERROR_CODE", {
        value: "E504",
        enumerable: !1,
        configurable: !0
    });
    class i {
        disable() {
            throw u
        }
        getStore() {}
        run() {
            throw u
        }
        exit() {
            throw u
        }
        enterWith() {
            throw u
        }
        static bind(e) {
            return e
        }
    }
    let a = "undefined" != typeof globalThis && globalThis.AsyncLocalStorage;

    function l() {
        return a ? new a : new i
    }

    function s(e) {
        return a ? a.bind(e) : i.bind(e)
    }

    function c() {
        return a ? a.snapshot() : function(e, ...t) {
            return e(...t)
        }
    }
}, 91763, (e, t, r) => {
    var n = {
            229: function(e) {
                var t, r, n, o = e.exports = {};

                function u() {
                    throw Error("setTimeout has not been defined")
                }

                function i() {
                    throw Error("clearTimeout has not been defined")
                }
                try {
                    t = "function" == typeof setTimeout ? setTimeout : u
                } catch (e) {
                    t = u
                }
                try {
                    r = "function" == typeof clearTimeout ? clearTimeout : i
                } catch (e) {
                    r = i
                }

                function a(e) {
                    if (t === setTimeout) return setTimeout(e, 0);
                    if ((t === u || !t) && setTimeout) return t = setTimeout, setTimeout(e, 0);
                    try {
                        return t(e, 0)
                    } catch (r) {
                        try {
                            return t.call(null, e, 0)
                        } catch (r) {
                            return t.call(this, e, 0)
                        }
                    }
                }
                var l = [],
                    s = !1,
                    c = -1;

                function f() {
                    s && n && (s = !1, n.length ? l = n.concat(l) : c = -1, l.length && d())
                }

                function d() {
                    if (!s) {
                        var e = a(f);
                        s = !0;
                        for (var t = l.length; t;) {
                            for (n = l, l = []; ++c < t;) n && n[c].run();
                            c = -1, t = l.length
                        }
                        n = null, s = !1,
                            function(e) {
                                if (r === clearTimeout) return clearTimeout(e);
                                if ((r === i || !r) && clearTimeout) return r = clearTimeout, clearTimeout(e);
                                try {
                                    r(e)
                                } catch (t) {
                                    try {
                                        return r.call(null, e)
                                    } catch (t) {
                                        return r.call(this, e)
                                    }
                                }
                            }(e)
                    }
                }

                function p(e, t) {
                    this.fun = e, this.array = t
                }

                function y() {}
                o.nextTick = function(e) {
                    var t = Array(arguments.length - 1);
                    if (arguments.length > 1)
                        for (var r = 1; r < arguments.length; r++) t[r - 1] = arguments[r];
                    l.push(new p(e, t)), 1 !== l.length || s || a(d)
                }, p.prototype.run = function() {
                    this.fun.apply(null, this.array)
                }, o.title = "browser", o.browser = !0, o.env = {}, o.argv = [], o.version = "", o.versions = {}, o.on = y, o.addListener = y, o.once = y, o.off = y, o.removeListener = y, o.removeAllListeners = y, o.emit = y, o.prependListener = y, o.prependOnceListener = y, o.listeners = function(e) {
                    return []
                }, o.binding = function(e) {
                    throw Error("process.binding is not supported")
                }, o.cwd = function() {
                    return "/"
                }, o.chdir = function(e) {
                    throw Error("process.chdir is not supported")
                }, o.umask = function() {
                    return 0
                }
            }
        },
        o = {};

    function u(e) {
        var t = o[e];
        if (void 0 !== t) return t.exports;
        var r = o[e] = {
                exports: {}
            },
            i = !0;
        try {
            n[e](r, r.exports, u), i = !1
        } finally {
            i && delete o[e]
        }
        return r.exports
    }
    u.ab = "/ROOT/node_modules/.pnpm/next@16.1.1_react-dom@19.2.3_react@19.2.3__react@19.2.3_sass@1.93.2/node_modules/next/dist/compiled/process/", t.exports = u(229)
}, 7240, (e, t, r) => {
    "use strict";
    var n, o;
    t.exports = (null == (n = e.g.process) ? void 0 : n.env) && "object" == typeof(null == (o = e.g.process) ? void 0 : o.env) ? e.g.process : e.r(91763)
}, 97357, (e, t, r) => {
    "use strict";
    var n = Symbol.for("react.transitional.element");

    function o(e, t, r) {
        var o = null;
        if (void 0 !== r && (o = "" + r), void 0 !== t.key && (o = "" + t.key), "key" in t)
            for (var u in r = {}, t) "key" !== u && (r[u] = t[u]);
        else r = t;
        return {
            $$typeof: n,
            type: e,
            key: o,
            ref: void 0 !== (t = r.ref) ? t : null,
            props: r
        }
    }
    r.Fragment = Symbol.for("react.fragment"), r.jsx = o, r.jsxs = o
}, 89822, (e, t, r) => {
    "use strict";
    t.exports = e.r(97357)
}, 70305, (e, t, r) => {
    "use strict";
    var n = e.i(7240),
        o = Symbol.for("react.transitional.element"),
        u = Symbol.for("react.portal"),
        i = Symbol.for("react.fragment"),
        a = Symbol.for("react.strict_mode"),
        l = Symbol.for("react.profiler"),
        s = Symbol.for("react.consumer"),
        c = Symbol.for("react.context"),
        f = Symbol.for("react.forward_ref"),
        d = Symbol.for("react.suspense"),
        p = Symbol.for("react.memo"),
        y = Symbol.for("react.lazy"),
        h = Symbol.for("react.activity"),
        _ = Symbol.for("react.view_transition"),
        b = Symbol.iterator,
        v = {
            isMounted: function() {
                return !1
            },
            enqueueForceUpdate: function() {},
            enqueueReplaceState: function() {},
            enqueueSetState: function() {}
        },
        m = Object.assign,
        g = {};

    function j(e, t, r) {
        this.props = e, this.context = t, this.refs = g, this.updater = r || v
    }

    function O() {}

    function w(e, t, r) {
        this.props = e, this.context = t, this.refs = g, this.updater = r || v
    }
    j.prototype.isReactComponent = {}, j.prototype.setState = function(e, t) {
        if ("object" != typeof e && "function" != typeof e && null != e) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
        this.updater.enqueueSetState(this, e, t, "setState")
    }, j.prototype.forceUpdate = function(e) {
        this.updater.enqueueForceUpdate(this, e, "forceUpdate")
    }, O.prototype = j.prototype;
    var S = w.prototype = new O;
    S.constructor = w, m(S, j.prototype), S.isPureReactComponent = !0;
    var E = Array.isArray;

    function x() {}
    var T = {
            H: null,
            A: null,
            T: null,
            S: null
        },
        P = Object.prototype.hasOwnProperty;

    function R(e, t, r) {
        var n = r.ref;
        return {
            $$typeof: o,
            type: e,
            key: t,
            ref: void 0 !== n ? n : null,
            props: r
        }
    }

    function A(e) {
        return "object" == typeof e && null !== e && e.$$typeof === o
    }
    var M = /\/+/g;

    function C(e, t) {
        var r, n;
        return "object" == typeof e && null !== e && null != e.key ? (r = "" + e.key, n = {
            "=": "=0",
            ":": "=2"
        }, "$" + r.replace(/[=:]/g, function(e) {
            return n[e]
        })) : t.toString(36)
    }

    function k(e, t, r) {
        if (null == e) return e;
        var n = [],
            i = 0;
        return ! function e(t, r, n, i, a) {
            var l, s, c, f = typeof t;
            ("undefined" === f || "boolean" === f) && (t = null);
            var d = !1;
            if (null === t) d = !0;
            else switch (f) {
                case "bigint":
                case "string":
                case "number":
                    d = !0;
                    break;
                case "object":
                    switch (t.$$typeof) {
                        case o:
                        case u:
                            d = !0;
                            break;
                        case y:
                            return e((d = t._init)(t._payload), r, n, i, a)
                    }
            }
            if (d) return a = a(t), d = "" === i ? "." + C(t, 0) : i, E(a) ? (n = "", null != d && (n = d.replace(M, "$&/") + "/"), e(a, r, n, "", function(e) {
                return e
            })) : null != a && (A(a) && (l = a, s = n + (null == a.key || t && t.key === a.key ? "" : ("" + a.key).replace(M, "$&/") + "/") + d, a = R(l.type, s, l.props)), r.push(a)), 1;
            d = 0;
            var p = "" === i ? "." : i + ":";
            if (E(t))
                for (var h = 0; h < t.length; h++) f = p + C(i = t[h], h), d += e(i, r, n, f, a);
            else if ("function" == typeof(h = null === (c = t) || "object" != typeof c ? null : "function" == typeof(c = b && c[b] || c["@@iterator"]) ? c : null))
                for (t = h.call(t), h = 0; !(i = t.next()).done;) f = p + C(i = i.value, h++), d += e(i, r, n, f, a);
            else if ("object" === f) {
                if ("function" == typeof t.then) return e(function(e) {
                    switch (e.status) {
                        case "fulfilled":
                            return e.value;
                        case "rejected":
                            throw e.reason;
                        default:
                            switch ("string" == typeof e.status ? e.then(x, x) : (e.status = "pending", e.then(function(t) {
                                "pending" === e.status && (e.status = "fulfilled", e.value = t)
                            }, function(t) {
                                "pending" === e.status && (e.status = "rejected", e.reason = t)
                            })), e.status) {
                                case "fulfilled":
                                    return e.value;
                                case "rejected":
                                    throw e.reason
                            }
                    }
                    throw e
                }(t), r, n, i, a);
                throw Error("Objects are not valid as a React child (found: " + ("[object Object]" === (r = String(t)) ? "object with keys {" + Object.keys(t).join(", ") + "}" : r) + "). If you meant to render a collection of children, use an array instead.")
            }
            return d
        }(e, n, "", "", function(e) {
            return t.call(r, e, i++)
        }), n
    }

    function H(e) {
        if (-1 === e._status) {
            var t = e._result;
            (t = t()).then(function(t) {
                (0 === e._status || -1 === e._status) && (e._status = 1, e._result = t)
            }, function(t) {
                (0 === e._status || -1 === e._status) && (e._status = 2, e._result = t)
            }), -1 === e._status && (e._status = 0, e._result = t)
        }
        if (1 === e._status) return e._result.default;
        throw e._result
    }
    var U = "function" == typeof reportError ? reportError : function(e) {
        if ("object" == typeof window && "function" == typeof window.ErrorEvent) {
            var t = new window.ErrorEvent("error", {
                bubbles: !0,
                cancelable: !0,
                message: "object" == typeof e && null !== e && "string" == typeof e.message ? String(e.message) : String(e),
                error: e
            });
            if (!window.dispatchEvent(t)) return
        } else if ("object" == typeof n.default && "function" == typeof n.default.emit) return void n.default.emit("uncaughtException", e);
        console.error(e)
    };

    function N(e) {
        var t = T.T,
            r = {};
        r.types = null !== t ? t.types : null, T.T = r;
        try {
            var n = e(),
                o = T.S;
            null !== o && o(r, n), "object" == typeof n && null !== n && "function" == typeof n.then && n.then(x, U)
        } catch (e) {
            U(e)
        } finally {
            null !== t && null !== r.types && (t.types = r.types), T.T = t
        }
    }

    function I(e) {
        var t = T.T;
        if (null !== t) {
            var r = t.types;
            null === r ? t.types = [e] : -1 === r.indexOf(e) && r.push(e)
        } else N(I.bind(null, e))
    }
    r.Activity = h, r.Children = {
        map: k,
        forEach: function(e, t, r) {
            k(e, function() {
                t.apply(this, arguments)
            }, r)
        },
        count: function(e) {
            var t = 0;
            return k(e, function() {
                t++
            }), t
        },
        toArray: function(e) {
            return k(e, function(e) {
                return e
            }) || []
        },
        only: function(e) {
            if (!A(e)) throw Error("React.Children.only expected to receive a single React element child.");
            return e
        }
    }, r.Component = j, r.Fragment = i, r.Profiler = l, r.PureComponent = w, r.StrictMode = a, r.Suspense = d, r.ViewTransition = _, r.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = T, r.__COMPILER_RUNTIME = {
        __proto__: null,
        c: function(e) {
            return T.H.useMemoCache(e)
        }
    }, r.addTransitionType = I, r.cache = function(e) {
        return function() {
            return e.apply(null, arguments)
        }
    }, r.cacheSignal = function() {
        return null
    }, r.cloneElement = function(e, t, r) {
        if (null == e) throw Error("The argument must be a React element, but you passed " + e + ".");
        var n = m({}, e.props),
            o = e.key;
        if (null != t)
            for (u in void 0 !== t.key && (o = "" + t.key), t) P.call(t, u) && "key" !== u && "__self" !== u && "__source" !== u && ("ref" !== u || void 0 !== t.ref) && (n[u] = t[u]);
        var u = arguments.length - 2;
        if (1 === u) n.children = r;
        else if (1 < u) {
            for (var i = Array(u), a = 0; a < u; a++) i[a] = arguments[a + 2];
            n.children = i
        }
        return R(e.type, o, n)
    }, r.createContext = function(e) {
        return (e = {
            $$typeof: c,
            _currentValue: e,
            _currentValue2: e,
            _threadCount: 0,
            Provider: null,
            Consumer: null
        }).Provider = e, e.Consumer = {
            $$typeof: s,
            _context: e
        }, e
    }, r.createElement = function(e, t, r) {
        var n, o = {},
            u = null;
        if (null != t)
            for (n in void 0 !== t.key && (u = "" + t.key), t) P.call(t, n) && "key" !== n && "__self" !== n && "__source" !== n && (o[n] = t[n]);
        var i = arguments.length - 2;
        if (1 === i) o.children = r;
        else if (1 < i) {
            for (var a = Array(i), l = 0; l < i; l++) a[l] = arguments[l + 2];
            o.children = a
        }
        if (e && e.defaultProps)
            for (n in i = e.defaultProps) void 0 === o[n] && (o[n] = i[n]);
        return R(e, u, o)
    }, r.createRef = function() {
        return {
            current: null
        }
    }, r.forwardRef = function(e) {
        return {
            $$typeof: f,
            render: e
        }
    }, r.isValidElement = A, r.lazy = function(e) {
        return {
            $$typeof: y,
            _payload: {
                _status: -1,
                _result: e
            },
            _init: H
        }
    }, r.memo = function(e, t) {
        return {
            $$typeof: p,
            type: e,
            compare: void 0 === t ? null : t
        }
    }, r.startTransition = N, r.unstable_useCacheRefresh = function() {
        return T.H.useCacheRefresh()
    }, r.use = function(e) {
        return T.H.use(e)
    }, r.useActionState = function(e, t, r) {
        return T.H.useActionState(e, t, r)
    }, r.useCallback = function(e, t) {
        return T.H.useCallback(e, t)
    }, r.useContext = function(e) {
        return T.H.useContext(e)
    }, r.useDebugValue = function() {}, r.useDeferredValue = function(e, t) {
        return T.H.useDeferredValue(e, t)
    }, r.useEffect = function(e, t) {
        return T.H.useEffect(e, t)
    }, r.useEffectEvent = function(e) {
        return T.H.useEffectEvent(e)
    }, r.useId = function() {
        return T.H.useId()
    }, r.useImperativeHandle = function(e, t, r) {
        return T.H.useImperativeHandle(e, t, r)
    }, r.useInsertionEffect = function(e, t) {
        return T.H.useInsertionEffect(e, t)
    }, r.useLayoutEffect = function(e, t) {
        return T.H.useLayoutEffect(e, t)
    }, r.useMemo = function(e, t) {
        return T.H.useMemo(e, t)
    }, r.useOptimistic = function(e, t) {
        return T.H.useOptimistic(e, t)
    }, r.useReducer = function(e, t, r) {
        return T.H.useReducer(e, t, r)
    }, r.useRef = function(e) {
        return T.H.useRef(e)
    }, r.useState = function(e) {
        return T.H.useState(e)
    }, r.useSyncExternalStore = function(e, t, r) {
        return T.H.useSyncExternalStore(e, t, r)
    }, r.useTransition = function() {
        return T.H.useTransition()
    }, r.version = "19.3.0-canary-f93b9fd4-20251217"
}, 59888, (e, t, r) => {
    "use strict";
    t.exports = e.r(70305)
}, 70223, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "HandleISRError", {
        enumerable: !0,
        get: function() {
            return o
        }
    });
    let n = "undefined" == typeof window ? e.r(44140).workAsyncStorage : void 0;

    function o({
        error: e
    }) {
        if (n) {
            let t = n.getStore();
            if (t ? .isStaticGeneration) throw e && console.error(e), e
        }
        return null
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 37066, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "HeadManagerContext", {
        enumerable: !0,
        get: function() {
            return n
        }
    });
    let n = e.r(81258)._(e.r(59888)).default.createContext({})
}, 25137, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function() {
            return a
        }
    });
    let n = e.r(89822),
        o = e.r(70223),
        u = {
            fontFamily: 'system-ui,"Segoe UI",Roboto,Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji"',
            height: "100vh",
            textAlign: "center",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center"
        },
        i = {
            fontSize: "14px",
            fontWeight: 400,
            lineHeight: "28px",
            margin: "0 8px"
        },
        a = function({
            error: e
        }) {
            let t = e ? .digest;
            return (0, n.jsxs)("html", {
                id: "__next_error__",
                children: [(0, n.jsx)("head", {}), (0, n.jsxs)("body", {
                    children: [(0, n.jsx)(o.HandleISRError, {
                        error: e
                    }), (0, n.jsx)("div", {
                        style: u,
                        children: (0, n.jsxs)("div", {
                            children: [(0, n.jsxs)("h2", {
                                style: i,
                                children: ["Application error: a ", t ? "server" : "client", "-side exception has occurred while loading ", window.location.hostname, " (see the", " ", t ? "server logs" : "browser console", " for more information)."]
                            }), t ? (0, n.jsx)("p", {
                                style: i,
                                children: `Digest: ${t}`
                            }) : null]
                        })
                    })]
                })]
            })
        };
    ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}, 19548, (e, t, r) => {
    "use strict";
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "setAttributesFromProps", {
        enumerable: !0,
        get: function() {
            return i
        }
    });
    let n = {
            acceptCharset: "accept-charset",
            className: "class",
            htmlFor: "for",
            httpEquiv: "http-equiv",
            noModule: "noModule"
        },
        o = ["onLoad", "onReady", "dangerouslySetInnerHTML", "children", "onError", "strategy", "stylesheets"];

    function u(e) {
        return ["async", "defer", "noModule"].includes(e)
    }

    function i(e, t) {
        for (let [r, i] of Object.entries(t)) {
            if (!t.hasOwnProperty(r) || o.includes(r) || void 0 === i) continue;
            let a = n[r] || r.toLowerCase();
            "SCRIPT" === e.tagName && u(a) ? e[a] = !!i : e.setAttribute(a, String(i)), (!1 === i || "SCRIPT" === e.tagName && u(a) && (!i || "false" === i)) && (e.setAttribute(a, ""), e.removeAttribute(a))
        }
    }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
        value: !0
    }), Object.assign(r.default, r), t.exports = r.default)
}]);